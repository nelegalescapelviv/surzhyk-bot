from config import TOKEN
from responses import get_response
import telebot

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(func=lambda message: True, content_types=['text', 'voice', 'audio', 'video_note', 'photo', 'sticker', 'animation'])
def handle_message(message):
    reply = get_response(message)
    if reply:
        bot.reply_to(message, reply)

bot.polling()