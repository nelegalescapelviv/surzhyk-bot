import random
import json

with open('responses.json', 'r', encoding='utf-8') as f:
    RESPONSES = json.load(f)

def get_response(message):
    if message.content_type == 'text':
        text = message.text.lower()
        for trigger, replies in RESPONSES['text'].items():
            if trigger in text:
                return random.choice(replies)
    elif message.content_type == 'voice':
        return random.choice(RESPONSES['voice'])
    elif message.content_type == 'video_note':
        return random.choice(RESPONSES['video_note'])
    elif message.content_type == 'sticker':
        return random.choice(RESPONSES['sticker'])
    elif message.content_type == 'animation':
        return random.choice(RESPONSES['animation'])
    elif message.content_type == 'photo':
        return random.choice(RESPONSES['photo'])
    return None