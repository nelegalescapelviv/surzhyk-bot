import os
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, ContextTypes, filters
import random

TOKEN = os.getenv("BOT_TOKEN")

RESPONSES = [
    "Та ти шо, знову почалось!",
    "Базар фильтруй, шановний.",
    "Ото ти влупив, як з пушки.",
    "Може хвате вже матюкатись, а?",
    "Я теє... бот, але ржачно з тебе."
]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Ну шо, пацани, я в деле. Підйобувати готовий.")

async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.lower()
    if any(word in text for word in ["хуй", "пизда", "єбать", "блядь", "сука", "нахуй"]):
        await update.message.reply_text(random.choice(RESPONSES))
    elif "бот" in text:
        await update.message.reply_text("Я тута. Хто крав мій респект?")
    else:
        if random.random() < 0.1:
            await update.message.reply_text(random.choice(RESPONSES))

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), echo))
    app.run_polling()